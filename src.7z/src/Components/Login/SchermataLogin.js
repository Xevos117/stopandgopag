import FormLogin from "./FormLogin"

function SchermataLogin(){
    return(      
         <body style={{backgroundImage: `url(${"../images/sfondoSchermate.jpg"})` }}>
        <FormLogin/>     
        </body>  
        )
}

export default SchermataLogin;