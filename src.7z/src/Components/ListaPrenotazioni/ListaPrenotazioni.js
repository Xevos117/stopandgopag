import Tabella from "../Generali/Generali/Tabella";
import PopupAttenzione from '../Generali/Generali/PopupAttenzione'
import {React, useState} from 'react';
import {Button} from "react-bootstrap"
require('bootstrap')

let intestazioni=["ciao","ciao2"]

let macchine=[{
    modello:"Crossland1X",
    prezzo:"30$",
    alimentazione:"GPL, 5",
    dataorainizio:"2021 ore 9"
  },
  {
    modello:"Crossland2X",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },
  {
    modello:"Crossland3X",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },
  {
    modello:"Crossland4X",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"Crossland5X",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX6",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX43",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX44",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },
  ]

  let array=[]
  jsontoarray()

  function jsontoarray(){  
    

      for(let i=0; i<macchine.length;i++){
        array[i]=[macchine[i].modello+i, macchine[i].prezzo, macchine[i].alimentazione]
      }
        console.log(array[0])
    }

    function modifica(){
      window.location.href="/SchermataModificaPrenotazione"
    }

function ListaPrenotazioni(){
  const [show, setShow] = useState(false);

    return(
        <>
        <h1 style={{paddingLeft:30, paddingTop:40, paddingBottom:5}}>Lista Prenotazioni</h1>

        <div style={{paddingLeft:30}}>        
          <Button href="/SchermataInserimentoPrenotazioni">Inserisci</Button>       
        </div>

        <Tabella 
        intestazioni={["Modifica","Elimina","Codice Prenotazione", "Codice Cliente", "Targa/Matricola mezzo","Data/ora inizio","Data/ora fine","Codice autista"]}
        righe={array}
        seleziona={true}
        modificaelimina={true}
        modifica={()=>{modifica()}}
        elimina={()=>{setShow(true)}}
        />
        

        <PopupAttenzione
          show={show}
          onHide={() => setShow(false)}  
          onConfirm={()=>setShow(false)}
          stringAttenzione={"Sei sicuro di voler eliminare questa prenotazione? Questa operazione non è reversibile"}
        />
        </>
    )
}

export default ListaPrenotazioni