import FormGestioneDatiPagamento from './FormGestioneDatiPagamento'


function SchermataGestioneDatiPagamento(){
    return(
        
        <body style={{backgroundImage: `url(${"../images/sfondoSchermate.jpg"})`}}> 
        <FormGestioneDatiPagamento/>
        
        </body>
    )
}

export default SchermataGestioneDatiPagamento;