import Tabella from "../Generali/Generali/Tabella";
import PopupAttenzione from '../Generali/Generali/PopupAttenzione'
import {React, useState} from 'react';
require('bootstrap')

let intestazioni=["ciao","ciao2"]

let macchine=[{
    modello:"Crossland1X",
    prezzo:"30$",
    alimentazione:"GPL, 5",
    dataorainizio:"2021 ore 9",
    IdAutista:null
  },
  {
    modello:"Crossland2X",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },
  {
    modello:"Crossland3X",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },
  {
    modello:"Crossland4X",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"Crossland5X",
    prezzo:"30$",
    alimentazione:"GPL, 5",
    IdAutista:null
  },{
    modello:"CrosslandX6",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5",
    IdAutista:null
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5",
    IdAutista:null
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5",
    IdAutista:null
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX43",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },{
    modello:"CrosslandX44",
    prezzo:"30$",
    alimentazione:"GPL, 5"
  },
  ]

  let array=[]
  jsontoarray()

  function jsontoarray(){  
    

      for(let i=0; i<macchine.length;i++){
        array[i]=[macchine[i].modello+i, macchine[i].prezzo, macchine[i].alimentazione, macchine[i].IdAutista]
      }
        console.log(array[0])
    }

    function modifica(){
      window.location.href="/SchermataModificaPrenotazione"
    }

function ListaCorse(){
  const [show, setShow] = useState(false);

    return(
        <>
        <h1 style={{paddingLeft:30, paddingTop:40, paddingBottom:5}}>Lista Prenotazioni</h1>

        <Tabella 
        intestazioni={["Accetta","Rifiuta","Codice Prenotazione", "Codice Cliente", "Targa/Matricola mezzo","Data/ora inizio","Data/ora fine","Codice autista"]}
        righe={array}
        seleziona={false}
        modificaelimina={true}
        modifica={()=>{modifica()}}
        elimina={()=>{setShow(true)}}
        autistamode={true}
        />

        <PopupAttenzione
          show={show}
          onHide={() => setShow(false)}  
          onConfirm={()=>setShow(false)}
          stringAttenzione={"Sei sicuro di voler rifiutare questa prenotazione? Questa operazione non è reversibile"}
        />
        </>
    )
}

export default ListaCorse