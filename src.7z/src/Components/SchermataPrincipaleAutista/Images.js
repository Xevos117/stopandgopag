import './images.css'
function Images(){
    return(
        <div class="container-fluid">
            <img src="/images/ImgHome.jpg" class="img-fluid" align="center" alt="..." style={{height:"450"}}/>
        </div>    )
}

export default Images;