import React from 'react';
import { MDBDataTable } from 'mdbreact';
import { Table } from 'react-bootstrap';
let i=0
let dati=[
        
{
   tipMezzo: 'Tiger Nixon 1',
   targa: 'System Architect',
   modello: 'Edinburgh',
   alimentazione: '61',
   colore: '2011/04/25',
   numPosti: '$320',
   anno: 'Tiger Nixon',
   optional: 'System Architect',
   descrizione: 'Edinburgh',
   stalloPark: '61',
   tariffaOra: '2011/04/25',
   sovrapprezzo: '$320',
   foto: '$320'
 },
{
tipMezzo: 'Tiger Nixon 2',
targa: 'System Architect',
modello: 'Edinburgh',
alimentazione: '61',
colore: '2011/04/25',
numPosti: '$320',
anno: 'Tiger Nixon',
optional: 'System Architect',
descrizione: 'Edinburgh',
stalloPark: '61',
tariffaOra: '2011/04/25',
sovrapprezzo: '$320',
foto: '$320'
},
{
tipMezzo: 'Tiger Nixon 3',
targa: 'System Architect',
modello: 'Edinburgh',
alimentazione: '61',
colore: '2011/04/25',
numPosti: '$320',
anno: 'Tiger Nixon',
optional: 'System Architect',
descrizione: 'Edinburgh',
stalloPark: '61',
tariffaOra: '2011/04/25',
sovrapprezzo: '$320',
foto: '$320'
},
{
tipMezzo: 'Tiger Nixon 4',
targa: 'System Architect',
modello: 'Edinburgh',
alimentazione: '61',
colore: '2011/04/25',
numPosti: '$320',
anno: 'Tiger Nixon',
optional: 'System Architect',
descrizione: 'Edinburgh',
stalloPark: '61',
tariffaOra: '2011/04/25',
sovrapprezzo: '$320',
foto: '$320'
},
{
tipMezzo: 'Tiger Nixon 5',
targa: 'System Architect',
modello: 'Edinburgh',
alimentazione: '61',
colore: '2011/04/25',
numPosti: '$320',
anno: 'Tiger Nixon',
optional: 'System Architect',
descrizione: 'Edinburgh',
stalloPark: '61',
tariffaOra: '2011/04/25',
sovrapprezzo: '$320',
foto: '$320'
},
{
tipMezzo: 'Tiger Nixon 6',
targa: 'System Architect',
modello: 'Edinburgh',
alimentazione: '61',
colore: '2011/04/25',
numPosti: '$320',
anno: 'Tiger Nixon',
optional: 'System Architect',
descrizione: 'Edinburgh',
stalloPark: '61',
tariffaOra: '2011/04/25',
sovrapprezzo: '$320',
foto: '$320'
},
{
tipMezzo: 'Tiger Nixon 7',
targa: 'System Architect',
modello: 'Edinburgh',
alimentazione: '61',
colore: '2011/04/25',
numPosti: '$320',
anno: 'Tiger Nixon',
optional: 'System Architect',
descrizione: 'Edinburgh',
stalloPark: '61',
tariffaOra: '2011/04/25',
sovrapprezzo: '$320',
foto: '$320'
},
{
tipMezzo: 'Tiger Nixon 8',
targa: 'System Architect',
modello: 'Edinburgh',
alimentazione: '61',
colore: '2011/04/25',
numPosti: '$320',
anno: 'Tiger Nixon',
optional: 'System Architect',
descrizione: 'Edinburgh',
stalloPark: '61',
tariffaOra: '2011/04/25',
sovrapprezzo: '$320',
foto: '$320'
},
{
tipMezzo: 'Tiger Nixon 9',
targa: 'System Architect',
modello: 'Edinburgh',
alimentazione: '61',
colore: '2011/04/25',
numPosti: '$320',
anno: 'Tiger Nixon',
optional: 'System Architect',
descrizione: 'Edinburgh',
stalloPark: '61',
tariffaOra: '2011/04/25',
sovrapprezzo: '$320',
foto: '$320'
},
{
tipMezzo: 'Tiger Nixon 10',
targa: 'System Architect',
modello: 'Edinburgh',
alimentazione: '61',
colore: '2011/04/25',
numPosti: '$320',
anno: 'Tiger Nixon',
optional: 'System Architect',
descrizione: 'Edinburgh',
stalloPark: '61',
tariffaOra: '2011/04/25',
sovrapprezzo: '$320',
foto: '$320'
},
{
tipMezzo: 'Tiger Nixon 11',
targa: 'System Architect',
modello: 'Edinburgh',
alimentazione: '61',
colore: '2011/04/25',
numPosti: '$320',
anno: 'Tiger Nixon',
optional: 'System Architect',
descrizione: 'Edinburgh',
stalloPark: '61',
tariffaOra: '2011/04/25',
sovrapprezzo: '$320',
foto: '$320'
},
{
tipMezzo: 'Tiger Nixon 12',
targa: 'System Architect',
modello: 'Edinburgh',
alimentazione: '61',
colore: '2011/04/25',
numPosti: '$320',
anno: 'Tiger Nixon',
optional: 'System Architect',
descrizione: 'Edinburgh',
stalloPark: '61',
tariffaOra: '2011/04/25',
sovrapprezzo: '$320',
foto: '$320'
},
{
tipMezzo: 'Tiger Nixon 13',
targa: 'System Architect',
modello: 'Edinburgh',
alimentazione: '61',
colore: '2011/04/25',
numPosti: '$320',
anno: 'Tiger Nixon',
optional: 'System Architect',
descrizione: 'Edinburgh',
stalloPark: '61',
tariffaOra: '2011/04/25',
sovrapprezzo: '$320',
foto: '$320'
},
{
tipMezzo: 'Tiger Nixon 14',
targa: 'System Architect',
modello: 'Edinburgh',
alimentazione: '61',
colore: '2011/04/25',
numPosti: '$320',
anno: 'Tiger Nixon',
optional: 'System Architect',
descrizione: 'Edinburgh',
stalloPark: '61',
tariffaOra: '2011/04/25',
sovrapprezzo: '$320',
foto: '$320'
},
{
tipMezzo: 'Tiger Nixon 15',
targa: 'System Architect',
modello: 'Edinburgh',
alimentazione: '61',
colore: '2011/04/25',
numPosti: '$320',
anno: 'Tiger Nixon',
optional: 'System Architect',
descrizione: 'Edinburgh',
stalloPark: '61',
tariffaOra: '2011/04/25',
sovrapprezzo: '$320',
foto: '$320'
},
{
tipMezzo: 'Tigeraaaaaa Nixon 16',
targa: 'System Architect',
modello: 'Edinburgh',
alimentazione: '61',
colore: '2011/04/25',
numPosti: '$320',
anno: 'Tiger Nixon',
optional: 'System Architect',
descrizione: 'Edinburgh',
stalloPark: '61',
tariffaOra: '2011/04/25',
sovrapprezzo: '$320',
foto: '$320'
}
]


const DatatablePage = () => {
  const data = {
    columns: [
      {
        label: 'Tip. mezzo',
        field: 'tipMezzo',
        sort: 'asc',
        width: 170
      },
      {
        label: 'Targa',
        field: 'targa',
        sort: 'asc',
        width: 170
      },
      {
        label: 'Modello',
        field: 'modello',
        sort: 'asc',
        width: 170
      },
      {
        label: 'Alimentazione',
        field: 'alimentazione',
        sort: 'asc',
        width: 170
      },
      {
        label: 'Colore',
        field: 'colore',
        sort: 'asc',
        width: 170
      },
      {
        label: 'Num. Posti',
        field: 'numPosti',
        sort: 'asc',
        width: 170
      },
      {
        label: 'Anno',
        field: 'anno',
        sort: 'asc',
        width: 170
      },
      {
        label: 'Optional',
        field: 'optional',
        sort: 'asc',
        width: 170
      },
      {
        label: 'Descrizione',
        field: 'descrizione',
        sort: 'asc',
        width: 170
      },
      {
        label: 'Stallo/Park',
        field: 'stalloPark',
        sort: 'asc',
        width: 170
      },
      {
        label: 'Tariffa ora',
        field: 'tariffaOra',
        sort: 'asc',
        width: 170
      },
      {
        label: 'Sovrapprezzo',
        field: 'sovrapprezzo',
        sort: 'asc',
        width: 170
      },
      {
        label: 'Foto',
        field: 'foto',
        sort: 'asc',
        width: 170
      }
    ],
    rows: [
      
    ]
      
    
  };

  console.log(dati[0][1])



  return (
    <div style={{paddingTop:20, paddingLeft:30, paddingRight:40}}>
 

    <MDBDataTable
      scrollX
      maxHeight="20vh"
      striped
      bordered
      small

      data={data}
    />
    
  </div>
  );
}

export default DatatablePage;
  
  