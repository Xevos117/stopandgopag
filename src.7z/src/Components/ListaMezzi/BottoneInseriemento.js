
import {Button} from "react-bootstrap"
import 'bootstrap/dist/css/bootstrap.min.css';


function BottoneInserimento(){

 

    return(
    <div style={{paddingLeft:150, paddingTop:40, paddingBottom:40}}>
        
        <Button href="/SchermataRegistrazioneMezzo">Inserisci</Button>
       
    </div>

    )
}

export default BottoneInserimento;