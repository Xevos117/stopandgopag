import FormInserimentoDatiPagamento from './FormInserimentoDatiPagamento'


function SchermataInserimentoDatiPagamento(){
    return(
        
        <body style={{backgroundImage: `url(${"../images/sfondoSchermate.jpg"})`}}> 
        <FormInserimentoDatiPagamento/>
        
        </body>
    )
}

export default SchermataInserimentoDatiPagamento;