import React from 'react';
import { MDBDataTable } from 'mdbreact';
import { Table } from 'react-bootstrap';



const DatatablePage = () => {
  const data = {
    columns: [
      {
        label: 'Nome',
        field: 'nome',
        sort: 'asc',
        width: 170
      },
      {
        label: 'Cognome',
        field: 'cognome',
        sort: 'asc',
        width: 170
      },
      {
        label: 'Email',
        field: 'email',
        sort: 'asc',
        width: 170
      },
      {
        label: 'Password',
        field: 'password',
        sort: 'asc',
        width: 170
      },
      {
        label: 'Data nascita',
        field: 'dataNascita',
        sort: 'asc',
        width: 170
      },
      {
        label: 'Codice fiscale',
        field: 'codFiscale',
        sort: 'asc',
        width: 170
      },
      {
        label: 'Carta identità',
        field: 'cartaIdentita',
        sort: 'asc',
        width: 170
      },
      {
        label: 'Num. Patente',
        field: 'numPatente',
        sort: 'asc',
        width: 170
      },
      {
        label: 'Num. Telefono',
        field: 'numTelefono',
        sort: 'asc',
        width: 170
      },
      {
        label: 'Iban',
        field: 'iban',
        sort: 'asc',
        width: 170
      },
      {
        label: 'Tariffa oraria',
        field: 'tariffaOraria',
        sort: 'asc',
        width: 170
      },
      {
        label: 'Ruolo',
        field: 'ruolo',
        sort: 'asc',
        width: 170
      },
      
    ],
    rows: [
      
            
            
        
             {
                nome: 'Tiger Nixon',
                cognome: 'System Architect',
                email: 'Edinburgh',
                password: '61',
                dataNascita: '2011/04/25',
                codFiscale: '$320',
                cartaIdentita: 'Tiger Nixon',
                numPatente: 'System Architect',
                numTelefono: 'Edinburgh',
                iban: '61',
                tariffaOraria: '2011/04/25',
                ruolo: '$320',
                
              },
            
              
             {
                nome: 'Tiger Nixon',
                cognome: 'System Architect',
                email: 'Edinburgh',
                password: '61',
                dataNascita: '2011/04/25',
                codFiscale: '$320',
                cartaIdentita: 'Tiger Nixon',
                numPatente: 'System Architect',
                numTelefono: 'Edinburgh',
                iban: '61',
                tariffaOraria: '2011/04/25',
                ruolo: '$320',
                
              },

              
             {
                nome: 'Tiger Nixon',
                cognome: 'System Architect',
                email: 'Edinburgh',
                password: '61',
                dataNascita: '2011/04/25',
                codFiscale: '$320',
                cartaIdentita: 'Tiger Nixon',
                numPatente: 'System Architect',
                numTelefono: 'Edinburgh',
                iban: '61',
                tariffaOraria: '2011/04/25',
                ruolo: '$320',
                
              },

              
             {
                nome: 'Tiger Nixon',
                cognome: 'System Architect',
                email: 'Edinburgh',
                password: '61',
                dataNascita: '2011/04/25',
                codFiscale: '$320',
                cartaIdentita: 'Tiger Nixon',
                numPatente: 'System Architect',
                numTelefono: 'Edinburgh',
                iban: '61',
                tariffaOraria: '2011/04/25',
                ruolo: '$320',
                
              },

              
             {
                nome: 'Tiger Nixon',
                cognome: 'System Architect',
                email: 'Edinburgh',
                password: '61',
                dataNascita: '2011/04/25',
                codFiscale: '$320',
                cartaIdentita: 'Tiger Nixon',
                numPatente: 'System Architect',
                numTelefono: 'Edinburgh',
                iban: '61',
                tariffaOraria: '2011/04/25',
                ruolo: '$320',
                
              }
       
    ]
  };

  return (
    <div style={{paddingTop:20, paddingLeft:30, paddingRight:40}}>
 

    <MDBDataTable
      scrollX
      maxHeight="20vh"
      striped
      bordered
      small
      data={data}
    />
    
  </div>
  );
}

export default DatatablePage;
  
  