import FormGestioneDipendente from "./FormGestioneDipendente";

function SchermataGestioneDipendente(){
    return(
        <>

        <body style={{backgroundImage: `url(${"../images/sfondoSchermate.jpg"})`, height:1200, paddingTop:40}}>
        
        <FormGestioneDipendente/>
        </body>
        </>
        )
}

export default SchermataGestioneDipendente;
