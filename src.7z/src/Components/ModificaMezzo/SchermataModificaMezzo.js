import FormModificaMezzo from "./FormModificaMezzo";

function SchermataModificaMezzo(){
    return(
        <>
        <body style={{backgroundImage: `url(${"../images/sfondoSchermate.jpg"})`, height:1000, paddingTop:40}}>
           
        <FormModificaMezzo/>
        </body>
        </>
        )
}

export default SchermataModificaMezzo;