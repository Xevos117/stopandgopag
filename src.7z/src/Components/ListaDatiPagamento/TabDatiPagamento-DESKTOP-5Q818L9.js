
import React from 'react';
import { MDBDataTable } from 'mdbreact';
import { Table } from 'react-bootstrap';



const DatatablePage = () => {
  const data = {
    columns: [
      {
        label: 'Nome intestatario',
        field: 'nomeIntestatario',
        sort: 'asc',
        width: 170
      },
      {
        label: 'Cognome intestatario',
        field: 'cognomeIntestatario',
        sort: 'asc',
        width: 170
      },
      {
        label: 'Carta di credito',
        field: 'cartaCredito',
        sort: 'asc',
        width: 170
      },
      {
        label: 'Mese scadenza',
        field: 'meseScadenza',
        sort: 'asc',
        width: 170
      },
      {
        label: 'annoScadenza',
        field: 'annoScadenza',
        sort: 'asc',
        width: 170
      },
      {
        label: 'CVV',
        field: 'cvv',
        sort: 'asc',
        width: 170
      }
      
    ],
    rows: [
      
            
            
        
             {
                nomeIntestatario: 'Tiger Nixon',
                cognomeIntestatario: 'System Architect',
                cartaCredito: 'Edinburgh',
                meseScadenza: '61',
                annoScadenza: '2011/04/25',
                cvv: '$320',
                
              },
              {
                nomeIntestatario: 'Tiger Nixon',
                cognomeIntestatario: 'System Architect',
                cartaCredito: 'Edinburgh',
                meseScadenza: '61',
                annoScadenza: '2011/04/25',
                cvv: '$320',
                
              },
              {
                nomeIntestatario: 'Tiger Nixon',
                cognomeIntestatario: 'System Architect',
                cartaCredito: 'Edinburgh',
                meseScadenza: '61',
                annoScadenza: '2011/04/25',
                cvv: '$320',
                
              },
              {
                nomeIntestatario: 'Tiger Nixon',
                cognomeIntestatario: 'System Architect',
                cartaCredito: 'Edinburgh',
                meseScadenza: '61',
                annoScadenza: '2011/04/25',
                cvv: '$320',
                
              },
              {
                nomeIntestatario: 'Tiger Nixon',
                cognomeIntestatario: 'System Architect',
                cartaCredito: 'Edinburgh',
                meseScadenza: '61',
                annoScadenza: '2011/04/25',
                cvv: '$320',
                
              },
              
            
              
          
       
    ]
  };

  return (
    <div style={{paddingTop:20, paddingLeft:30, paddingRight:40}}>
 

    <MDBDataTable
      scrollX
      maxHeight="20vh"
      striped
      bordered
      small
      data={data}
    />
    
  </div>
  );
}

export default DatatablePage;
  
  