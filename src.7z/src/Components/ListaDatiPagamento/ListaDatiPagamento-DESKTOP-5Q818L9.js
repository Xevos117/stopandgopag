import TabDatiPagamento from "./TabDatiPagamento";
import BottoneInserimento from "./BottoneInseriemento";
import NavbarLoggato from "../Generali/Generali/NavbarLoggato";

function ListaDatiPagamento(){
    return(
        <body >
        <NavbarLoggato/>
        <h1 style={{paddingLeft:30, paddingTop:40, paddingBottom:5}}>Lista dati pagamento</h1>
        <TabDatiPagamento/>
        <BottoneInserimento/>
      
        </body>
    )
}

export default ListaDatiPagamento;