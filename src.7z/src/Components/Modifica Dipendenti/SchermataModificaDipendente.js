import FormModificaDipendente from "./FormModificaDipendente";

function SchermataModificaDipendente(){
    return(
        <>

        <body style={{backgroundImage: `url(${"../images/sfondoSchermate.jpg"})`, height:1200, paddingTop:40}}>
        
        <FormModificaDipendente/>
        </body>
        </>
        )
}

export default SchermataModificaDipendente;
