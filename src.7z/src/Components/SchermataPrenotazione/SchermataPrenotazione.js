import {Row,Col, Collapse, Button, Form} from "react-bootstrap"
import {useState} from 'react'
import PopupSuccesso from "../Generali/Generali/PopupSuccesso"

let macchine=[{
    modello:" Opel CrosslandX",
    prezzo:"30$",
    alimentazione:"GPL",
    numeroPosti:"5",
    autista:true
  }]

  let stringabottone="Dettagli pagamento"
  let stringariepilogo="Prenotazione"
function SchermataPrenotazione(){
    const [open, setOpen] = useState(true); //primoform
    const [open2, setOpen2] = useState(false);//secondoform
    const [open3, setOpen3] = useState(false);//indirizzodiverso
    const [show, setShow] = useState(false);  //per mostrare o nascondere il popupSuccesso
    
    function handleChange(){
        let c=document.getElementById("opzioniconsegna").value
        console.log(document.getElementById("opzioniconsegna").value==="altro")
        if(document.getElementById("opzioniconsegna").value==="altro"){
            document.getElementById("Indirizzodiverso").required=true
            document.getElementById("Cap").required=true
            document.getElementById("Citta").required=true
            setOpen3(true)
        }
        else{
            document.getElementById("Indirizzodiverso").required=false
            document.getElementById("Cap").required=false
            document.getElementById("Citta").required=false
            document.getElementById("Indirizzodiverso").value=""
            document.getElementById("Cap").value=""
            document.getElementById("Citta").value=""
            setOpen3(false)
        }
    }

    function mostraPopup(){
        show=true
    }

    function bottoneform(){
        var form
        if(open===true){
            stringabottone="Dettagli prenotazioni"
            form=document.getElementById("formdettagliparcheggio")
            if(form.checkValidity()===true){
                stringariepilogo="Pagamento"
                setOpen(false)
                setOpen2(true)
            }
        }
        else{
            stringabottone="Dettagli pagamento"
            stringariepilogo="Prenotazione"
            setOpen2(false)
            setOpen(true)
        }
    }

    return(
        <>
        <div className="container" style={{minHeight:600, paddingTop:30, backgroundColor:"#f2f2f2"}}>
            <Row>
                <Col>
                <img src="../images/opelCrossland.png"></img>
                </Col>
                <Col>
                <h3><strong>Opel CrosslandX</strong></h3>
                <p>Suv adatto a lunghe percorrenze in autostrada. Perfetto per un weekend fuori porta</p>
                <p><strong>Alimentazione: </strong><text>{macchine[0].alimentazione}</text> <strong style={{marginLeft:10}}>Numero Posti: </strong><text>{macchine[0].numeroPosti}</text></p>
                <h5>Optional</h5>
                <p>
                    <ul>
                        <li>Clima</li>
                        <li>Fari full LED</li>
                    </ul>
                </p>

                </Col>
            </Row>   
            <Row style={{backgroundColor:"#e6e6e6"}}>
                <Col>
                <h2>Riepilogo {stringariepilogo}</h2> 
                <Collapse in={open}>
                <div>
                <p><strong>Cliente: </strong>Alaimo</p>  
                <p><strong>Modello: </strong> {macchine[0].modello}</p>
                <p><strong>Data e ora di ritiro: </strong>22/09/2021 9:00</p> 
                <p><strong>Data e ora di consegna: </strong>25/09/2021 18:00</p> 
                </div>
                </Collapse> 
                <Collapse in={open2}>
                <div>
                    <p><strong>Tariffa autista: </strong>10</p>  
                    <p><strong>Tariffa oraria mezzo: </strong> 10</p>
                    <Collapse in={open3}>
                    <p><strong>Tariffa destinazione diversa </strong>10</p> 
                    </Collapse>
                    <p><strong>Durata corsa</strong>1 giorno</p> 
                </div>
                </Collapse>               
                </Col>
                <Col>
                <Button
                    onClick={bottoneform}
                    aria-controls="example-collapse-text"
                    id="avanti"
                    aria-expanded={open}
                    style={{marginTop:10}}
                >
                    {stringabottone}
                </Button>                
                <Collapse in={open} style={{paddingBottom:30}}>
                    <div id="parcheggio">
                    <Form id="formdettagliparcheggio">
                    <Form.Group as={Col} controlId="parcheggioritiro">
                        <Form.Label ><strong>Parcheggio/Stallo ritiro</strong></Form.Label>
                            <select className="form-select mb3" id="opzioniritiro">
                            <option selected value="as">Parcheggio4</option>
                            <option value="">Parcheggio1</option>
                            <option value="">Parcheggio2</option>
                            <option value="">Parcheggio3</option>
                            </select>
                    </Form.Group> 
                    <Form.Group as={Col} controlId="parcheggioconsegna">
                        <Form.Label ><strong>Parcheggio/Stallo consegna</strong></Form.Label>                        
                            <select className="form-select mb3" id="opzioniconsegna" onChange={handleChange}>
                            <option selected="selected" value="as">Parcheggio4</option>
                            <option value="altro">Altro</option>
                            <option value="">Parcheggio1</option>
                            <option value="">Parcheggio2</option>
                            <option value="">Parcheggio3</option>
                            </select>
                    </Form.Group>  
                    
                    <Collapse in={open3}>
                        <div id="example-collapse-text">
                        <Form.Group as={Col} controlId="Indirizzodiverso">
                         <Form.Label><strong>Destinazione diversa indirizzo</strong></Form.Label>
                          <Form.Control type="text" placeholder="Inserisci se non consegni in un parcheggio/stallo"/>
                            </Form.Group>  
                            <Row>
                            <Form.Group as={Col} controlId="Cap">
                                <Form.Label><strong>Destinazione diversa CAP</strong></Form.Label>
                                <Form.Control type="text" placeholder=""/>
                            </Form.Group>
                            <Form.Group as={Col} controlId="Citta">
                                <Form.Label><strong>Destinazione diversa città</strong></Form.Label>
                                <Form.Control type="text" placeholder=""/>
                            </Form.Group>
                            </Row>  
                        </div>
                    </Collapse>   
                    <Collapse in={macchine[0].autista} >
                        <div id="collapse-autista">
                        <Row>
                            <Col>
                            <label for="exampleFormControlTextarea1"><strong>Note per autista</strong></label>
                            <textarea class="form-control" placeholder="Inserire eventuali note come: indirizzo di partenza, percorso..." id="descrizioneMezzo" rows="3"></textarea>
                        
                            </Col>
                            </Row>
                        </div>
                    </Collapse> 
                    
                    </Form>
                    </div>
                </Collapse>
                <Collapse in={open2}>
                    <div id="selezionapagamento">
                    <Form>
                    <Form.Group className="mb-3" controlId="metodopagamento" >
                    <Form.Label><strong>Metodo Pagamento</strong></Form.Label>
                        <select className="form-select mb3" id="opzioniconsegna" onChange={handleChange}>
                            <option value="">Pagamento 1</option>                            
                            </select>
                    </Form.Group>
                    <Collapse in={macchine[0].autista}>
                        <Form.Group as={Col} controlId="mancia">
                            <Form.Label><strong>Mancia autista</strong></Form.Label>
                            <Form.Control type="number" placeholder="" min="0"/>
                        </Form.Group>
                    </Collapse>
                    
                    </Form>
                    <p><strong style={{fontSize:24}}>Totale: 40$</strong></p>
                    <Button variant="success" size="lg" onClick={()=>setShow(true)} style={{marginBottom:10}}>
                        Paga ora
                    </Button>
                    </div>
                </Collapse>
                </Col>
            </Row>                   
                                 
                                 
            </div>
            <PopupSuccesso
                id="popup"
                show={show}     
                onHide={()=>setShow(false)} 
                onConfirm={()=>{setShow(false)}}          
                titolo={"Confermare la prenotazione?"}
                stringAttenzione={"Cliccando continua verrà confermata definitivamente la prenotazione ed avverrà il pagamento"}
            />
        </>
    )
}

export default SchermataPrenotazione