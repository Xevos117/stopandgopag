import ModificaDatoPagamento from './ModificaDatoPagamento'


function SchermataModificaDatiPagamento(){
    return(
        
        <body style={{backgroundImage: `url(${"../images/sfondoSchermate.jpg"})`}}> 
        <ModificaDatoPagamento/>
        
        </body>
    )
}

export default SchermataModificaDatiPagamento;