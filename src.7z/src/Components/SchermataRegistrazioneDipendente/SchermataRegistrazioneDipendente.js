import FormRegistrazioneDipendente from "./FormRegistrazioneDipendente";

function SchermataRegistrazioneDipendente(){
    return(
        <>

        <body style={{backgroundImage: `url(${"../images/sfondoSchermate.jpg"})`, height:1200, paddingTop:40}}>
        
        <FormRegistrazioneDipendente/>
        </body>
        </>
        )
}

export default SchermataRegistrazioneDipendente;
