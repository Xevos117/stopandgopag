import FormRicerca from './FormRicerca'

function SchermataPrincipale(){
    return(
        <body  style={{backgroundImage: `url(${"../images/sfondoSchermate.jpg"})`}}>
        
        <FormRicerca/>      
        
        </body>
    )
}

export default SchermataPrincipale;